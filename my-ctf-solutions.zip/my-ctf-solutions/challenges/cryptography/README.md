# 🔐 Cryptography

Challenges that involve encodings, ciphers, and hashes: recognizing them, understanding how they work, and decoding or decrypting data with the information provided.

## Typical topics

- Encodings (Base64, hex, ROT13)
- Classical ciphers
- Hashing
- Basic symmetric / public-key concepts

## Challenges

| Challenge | Difficulty | Points | Status | Writeup |
|-----------|------------|--------|--------|---------|
| _No writeups added yet_ | – | – | – | – |

<!-- Example row (copy, edit, and remove this comment):
| Challenge Name | Easy | 100 | ✅ | [Link](challenge-name/README.md) |
-->

## Adding a writeup

Run these from the **repository root**:

```bash
mkdir -p challenges/cryptography/<challenge-name>/screenshots
cp writeup-template.md challenges/cryptography/<challenge-name>/README.md
```

Then add a row to the table above and to the main [Challenge Index](../../README.md#-challenge-index).

[← Back to main README](../../README.md)
