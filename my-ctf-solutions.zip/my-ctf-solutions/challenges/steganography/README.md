# 🖼️ Steganography

Challenges that involve data hidden inside other files such as images or audio.

## Typical topics

- Metadata inspection
- Hidden/appended data
- LSB analysis
- Extraction tools

## Challenges

| Challenge | Difficulty | Points | Status | Writeup |
|-----------|------------|--------|--------|---------|
| _No writeups added yet_ | – | – | – | – |

<!-- Example row (copy, edit, and remove this comment):
| Challenge Name | Easy | 100 | ✅ | [Link](challenge-name/README.md) |
-->

## Adding a writeup

Run these from the **repository root**:

```bash
mkdir -p challenges/steganography/<challenge-name>/screenshots
cp writeup-template.md challenges/steganography/<challenge-name>/README.md
```

Then add a row to the table above and to the main [Challenge Index](../../README.md#-challenge-index).

[← Back to main README](../../README.md)
