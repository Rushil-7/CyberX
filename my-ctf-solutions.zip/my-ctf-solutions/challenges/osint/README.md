# 🌍 OSINT

Challenges that involve finding and verifying information from public sources, within the scope defined by the challenge.

## Typical topics

- Search operators
- Reverse image search
- Metadata and geolocation clues
- Archived web pages
- Cross-verifying sources

## Challenges

| Challenge | Difficulty | Points | Status | Writeup |
|-----------|------------|--------|--------|---------|
| _No writeups added yet_ | – | – | – | – |

<!-- Example row (copy, edit, and remove this comment):
| Challenge Name | Easy | 100 | ✅ | [Link](challenge-name/README.md) |
-->

## Adding a writeup

Run these from the **repository root**:

```bash
mkdir -p challenges/osint/<challenge-name>/screenshots
cp writeup-template.md challenges/osint/<challenge-name>/README.md
```

Then add a row to the table above and to the main [Challenge Index](../../README.md#-challenge-index).

[← Back to main README](../../README.md)
