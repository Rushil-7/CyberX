# 🐧 Linux

Challenges that involve the Linux command line: navigating the file system, reading files, searching for data, understanding permissions, and working over SSH.

## Typical topics

- Navigation and file inspection (`ls`, `cat`, `cd`)
- Searching with `grep` and `find`
- File permissions
- Pipes and redirection
- SSH

## Challenges

| Challenge | Difficulty | Points | Status | Writeup |
|-----------|------------|--------|--------|---------|
| _No writeups added yet_ | – | – | – | – |

<!-- Example row (copy, edit, and remove this comment):
| Challenge Name | Easy | 100 | ✅ | [Link](challenge-name/README.md) |
-->

## Adding a writeup

Run these from the **repository root**:

```bash
mkdir -p challenges/linux/<challenge-name>/screenshots
cp writeup-template.md challenges/linux/<challenge-name>/README.md
```

Then add a row to the table above and to the main [Challenge Index](../../README.md#-challenge-index).

[← Back to main README](../../README.md)
