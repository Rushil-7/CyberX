# 🔎 Forensics

Challenges that involve analyzing files, disk images, memory dumps, or network captures to uncover what happened or find hidden information.

## Typical topics

- File identification and metadata
- Strings and hex inspection
- Embedded/carved files
- Network capture analysis

## Challenges

| Challenge | Difficulty | Points | Status | Writeup |
|-----------|------------|--------|--------|---------|
| _No writeups added yet_ | – | – | – | – |

<!-- Example row (copy, edit, and remove this comment):
| Challenge Name | Easy | 100 | ✅ | [Link](challenge-name/README.md) |
-->

## Adding a writeup

Run these from the **repository root**:

```bash
mkdir -p challenges/forensics/<challenge-name>/screenshots
cp writeup-template.md challenges/forensics/<challenge-name>/README.md
```

Then add a row to the table above and to the main [Challenge Index](../../README.md#-challenge-index).

[← Back to main README](../../README.md)
